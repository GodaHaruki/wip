extends Node2D

const music_file_path = ""

@export var note_scene: PackedScene

@onready var lanes = [$lanes/lane0, $lanes/lane1, $lanes/lane2, $lanes/lane3]
@onready var audio_file = FileAccess.open(music_file_path.path_join("./audio.mp3"), FileAccess.READ)
@onready var notes_file = FileAccess.open(music_file_path.path_join("./notes.csv"), FileAccess.READ)

# will be [[perfect_time, note_place, note_type, softlanding_speed]] 
var notes_file_lines = []

func _ready():
	while notes_file.eof_reached():
		notes_file_lines.append(notes_file.get_csv_line())

var player_place = 0
var start_time: float = Time.get_unix_time_from_system()

func _process(delta):
	for i in range(4):
		var note_info = notes_file_lines[i]
		if float(note_info[0]) <= Time.get_unix_time_from_system() + 10 - start_time:
			add_note(float(note_info[0]), int(note_info[1]), int(note_info[2]), float(note_info[3]))
		
	# input event
	if Input.is_action_just_pressed("left"):
		if player_place != 0:
			player_place -= 1
	elif Input.is_action_just_pressed("right"):
		if player_place != 4:
			player_place += 1

func move_notes():
	var pixel = 0 # todo!
	for lane in lanes:
		var notes = lane.get_children()
		for note in notes:
			var now_time = Time.get_unix_time_from_system()
			note.position = Vector2(
				0.0,
				pixel - pixel * Setting.speed * (note.perfect_time - now_time)
			)
	pass	

func add_note(perfect_time: float, place: int, type: int, softlanding_speed: float):
	var lane = lanes[place]
	
	var new_note = note_scene.instantiate()
	
	new_note.position = Vector2(0, 0)
	new_note.perfect_time = perfect_time
	new_note.softlanding_speed = softlanding_speed
	
	lane.add_child(new_note)
