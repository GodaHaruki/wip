extends Node

@export var speed: float
