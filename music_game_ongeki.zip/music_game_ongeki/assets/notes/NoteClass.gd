extends Sprite2D

class_name Note

var softlanding_speed: float = 1
var perfect_time: float
