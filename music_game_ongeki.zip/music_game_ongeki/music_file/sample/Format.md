# Music File Format
##  Extension
todo

## Format
UTF-8

## Spec
perfect_time, note_place, note_type, softlanding_speed
truly csv file
note_place will be 0 to 3
note_type will be 0 to 3
speed * softlanding speed will be speed. so when you want to turn off softlan, softlanding_speed should be 1

| note_type | explanation |
| --- | --- |
| 0 | normal note | 
| 1 | left to right direction note |
| 2 | right to left direction note |
| 3 | damate note |

## Example
damage note: x
normal note: o

5.00,0,1,1
5.00,3,0,1
5.00,3,2,1
5.00,3,3,1

oxoo
