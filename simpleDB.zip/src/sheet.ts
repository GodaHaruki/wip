const APP_URL = ""

type Data = {
  key: string
  value: any
}

type __GetResult = [any | null, number | null]

class Sheet {
  sheet: GoogleAppsScript.Spreadsheet.Sheet

  constructor(sheetName: string) {
    const temp = SpreadsheetApp
      .openByUrl(APP_URL)
      .getSheetByName(sheetName);
    if (temp === null) {
      throw TypeError(`sheetName "${sheetName}" is not found`);
    }
    this.sheet = temp!;
  }

  __get(key: string, values: (string | any)[][]): __GetResult {
    // let index: number | null = null
    // const t = values.find((v, i) => { index = i; v[0] == key });

    for (let i = 0; i < values.length; i++) {
      const v = values[i];
      if (v[0] === key) { return [v[1], i] }
    }

    return [null, null]
  }

  get(key: string): any | null {
    const lastRow = this.sheet.getLastRow()
    const range = this.sheet.getRange(1, 1, lastRow, 2);

    return this.__get(key, range.getValues())[0];
  }

  put(key: string, value: any) {
    const lastRow = this.sheet.getLastRow()
    const range = this.sheet.getRange(1, 1, lastRow, 2);
    if (this.__get(key, range.getValues()) === null) {
      range.setValues([[key, value]]);
    }
  }
}