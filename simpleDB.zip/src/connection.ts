function doGet(e: any){
  let output = ContentService.createTextOutput();
  output.setMimeType(ContentService.MimeType.JSON)
}